<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RekomendasiController extends Controller
{
    public function handleSubmit(Request $request)
    {
        $validated = $request->validate([
            'prosesor' => 'required',
            'harga' => 'required',
            'memori' => 'required',
            'ram' => 'required',
            'resolusi' => 'required',
            'kamera' => 'required',
            'baterai' => 'required',
        ]);
 
        return view('hasil', ['prosesor' => $validated['prosesor'], 
            'harga' => $validated['harga'], 
            'memori' => $validated['memori'], 
            'ram' => $validated['ram'], 
            'resolusi' => $validated['resolusi'], 
            'kamera' => $validated['kamera'], 
            'baterai' => $validated['baterai']]);
    }
}
